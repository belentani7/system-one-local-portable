/**
 * System One Local — barrel público.
 *
 * NOTA: NO re-exportamos `engine.ts` aquí porque ese módulo importa
 * `z-ai-web-dev-sdk` (server-only con `fs/promises`). Si el barrel lo
 * incluyera, los Client Components (como page.tsx) arrastrarían el SDK
 * al bundle del navegador y romperían la compilación.
 *
 * El motor se importa directamente desde `./engine` SOLO en server code
 * (API routes). Tipos y helpers puros son seguros para el cliente.
 */
export * from "./schema";
export * from "./confidence";
export * from "./presets";
